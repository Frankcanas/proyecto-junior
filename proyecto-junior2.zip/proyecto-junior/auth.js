import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
// import { getAuth, signInWithPopup, GoogleAuthProvider } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// Configuración de tu proyecto
const firebaseConfig = {
    apiKey: "AIzaSyBFLP3gn--kqed7Hm754WHBdD3Won_7NYA",
    authDomain: "proyecto-junior-1494d.firebaseapp.com",
    projectId: "proyecto-junior-1494d",
    storageBucket: "proyecto-junior-1494d.firebasestorage.app",
    messagingSenderId: "615433041867",
    appId: "1:615433041867:web:78ac207a4d09e714c4e84e",
    measurementId: "G-SLZ7E9QXLQ"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// --- LÓGICA PARA EL BOTÓN DE GOOGLE ---
const btnGoogle = document.getElementById('google-login');

if (btnGoogle) {
    btnGoogle.addEventListener('click', async (e) => {
        e.preventDefault();
        console.log("1. Intentando abrir ventana de Google..."); 
        
        try {
            const result = await signInWithPopup(auth, provider);
            console.log("2. Éxito al conectar:", result.user.displayName);
            
            // Guardamos los datos para el Header del index
            localStorage.setItem('usuarioJunior', JSON.stringify({
                usuario: result.user.displayName,
                foto: result.user.photoURL
            }));
            
            console.log("3. Redirigiendo al inicio...");
            window.location.href = "index.html"; 
        } catch (error) {
            console.error("Error detallado de Firebase:", error.code);
            // Si el error es popup-closed-by-user no mostramos alerta, solo log
            if (error.code !== 'auth/popup-closed-by-user') {
                alert("Error al conectar: " + error.message);
            }
        }
    });
}

// --- LÓGICA PARA EL FORMULARIO MANUAL (EMAIL) ---
const loginForm = document.getElementById('login-form');
if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value; // ID corregido
        const pass = document.getElementById('password').value;

        localStorage.setItem('usuarioJunior', JSON.stringify({
            usuario: email,
            foto: 'img/escudo.png' // Foto por defecto
        }));
        
        alert("¡Bienvenido al portal del Tiburón!");
        window.location.href = "index.html"; 
    });
}

const registerForm = document.getElementById('register-form');

if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        console.log("1. Intentando registrar usuario..."); // Para ver si el botón funciona

        const name = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        const pass = document.getElementById('reg-password').value;

        try {
            // Crear el usuario en Firebase
            const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
            console.log("2. Usuario creado en Firebase:", userCredential.user.email);

            // Guardar en LocalStorage para que el index lo reconozca
            const datosUsuario = {
                usuario: name,
                foto: 'img/escudo.png' 
            };
            localStorage.setItem('usuarioJunior', JSON.stringify(datosUsuario));
            console.log("3. Datos guardados en LocalStorage");

            alert("¡Bienvenido a la familia del Tiburón, " + name + "!");
            window.location.href = "index.html";

        } catch (error) {
            console.error("Error completo:", error.code, error.message);
            
            // Mensajes amigables para el usuario
            if (error.code === 'auth/email-already-in-use') {
                alert("Este correo ya está en uso. Intenta iniciar sesión.");
            } else if (error.code === 'auth/weak-password') {
                alert("La contraseña es muy corta (mínimo 6 caracteres).");
            } else {
                alert("Hubo un problema: " + error.message);
            }
        }
    });
}