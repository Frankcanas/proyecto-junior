// Inicializar la librería de animaciones
AOS.init({
    duration: 1000, 
    once: true      
});

console.log("¡Página del Junior lista!");



document.addEventListener("DOMContentLoaded", function() {
    
    // 1. Seleccionamos todos los elementos que queremos animar
    const elementsToReveal = document.querySelectorAll('.reveal');

    // 2. Definimos la configuración del observador
    const observerOptions = {
        root: null, // Usa el viewport del navegador
        rootMargin: '0px', // Sin margen adicional
        threshold: 0.15 // El elemento debe ser visible al menos un 15%
    };

    // 3. Creamos la función que se ejecuta cuando se detecta intersección
    const revealOnScroll = new IntersectionObserver(function(entries, observer) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Si el elemento es visible, añadimos la clase 'active'
                entry.target.classList.add('active');
                // Dejamos de observar el elemento para que la animación solo ocurra una vez
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // 4. Activamos el observador para cada elemento seleccionado
    elementsToReveal.forEach(element => {
        revealOnScroll.observe(element);
    });

});

console.log("Animaciones de Scroll y Hover cargadas.");

window.onscroll = function() {
    scrollFunction();
};

function scrollFunction() {
    const header = document.querySelector("header");
    
    // Si el usuario baja más de 80 pixeles, añade la clase 'pequeno'
    if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
        header.classList.add("pequeno");
    } else {
        // Si vuelve arriba del todo, quita la clase para que regrese a la normalidad
        header.classList.remove("pequeno");
    }
}


// 1. Base de datos de los ídolos
// 1. Tu lista de ídolos (Asegúrate de que esté completa)
const idolos = [
    {
        nombre: "Carlos Valderrama",
        apodo: "El Pibe",
        descripcion: "El máximo referente del fútbol colombiano. Bicampeón 93-95.",
        imagen: "img/pibe.jpg",
        videoUrl: "https://www.youtube.com/watch?v=3zISM8ijb8c",
        titulos: "1993, 1995"
    },
    {
        nombre: "Giovanni Hernández",
        apodo: "El Príncipe",
        descripcion: "Líder y 10 clásico que guio al equipo a la séptima estrella.",
        imagen: "img/giovanni.jpg",
        videoUrl: "https://www.youtube.com/embed/ECFrA54RIo0",
        titulos: "2010, 2011"
    },

    {
        nombre: "Sebastian Viera",
        apodo: "El Ángel",
        descripcion: "El capitán más ganador de la historia del club.",
        imagen: "img/viera.jpg",
        videoUrl: "https://www.youtube.com/embed/rXi4_5mHED8",
        titulos: "7 Títulos"
    }
];

// 2. La función que "dibuja" a los ídolos
function cargarIdolos() {
    const contenedor = document.getElementById('contenedor-idolos');
    if (!contenedor) return;

    contenedor.innerHTML = ""; 

    idolos.forEach((idolo) => {
        // Dentro de tu idolo.forEach:
            const card = `
                <div class="idolo-card" onclick="mostrarDetalle('${idolo.nombre}')">
                <div class="img-container">
                    <img src="${idolo.imagen}" alt="${idolo.nombre}">
                        <div class="overlay-resumen">
                        <h4>${idolo.nombre}</h4> <p>${idolo.descripcion}</p>
                        <span>VER MÁS</span>
                        </div>
                </div>
                    <div class="info-basica">
                    <h3>${idolo.nombre}</h3>
                    <p class="apodo">${idolo.apodo}</p>
                    </div>
                </div>
            `;
        contenedor.innerHTML += card;
    });
}

// 3. Función UNIFICADA para cuando cargue la página
document.addEventListener("DOMContentLoaded", function() {
    // Carga los ídolos primero
    cargarIdolos();
    
    // Inicia las animaciones de AOS (si las usas)
    if (typeof AOS !== 'undefined') {
        AOS.init();
    }

    // Escucha el scroll para el header
    window.addEventListener("scroll", function() {
        const header = document.querySelector("header");
        if (window.scrollY > 80) {
            header.classList.add("pequeno");
        } else {
            header.classList.remove("pequeno");
        }
    });
});

// 4. No olvides las funciones del Modal (mostrarDetalle y cerrarModal) que pusimos antes
function mostrarDetalle(nombre) {
    const modal = document.getElementById('modal-idolo');
    const idolo = idolos.find(i => i.nombre === nombre);

    document.getElementById('modal-titulo').innerText = idolo.nombre;
    document.getElementById('modal-descripcion').innerText = idolo.descripcion;
    const videoConParametros = `${idolo.videoUrl}?enablejsapi=1&origin=${window.location.origin}`;
    document.getElementById('video-placeholder').innerHTML = `
    <iframe 
        src="${videoConParametros}" 
        frameborder="0" 
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
        referrerpolicy="strict-origin-when-cross-origin"
        allowfullscreen>
    </iframe>
    
`;
    document.getElementById('modal-descripcion').innerHTML = `
    ${idolo.descripcion}
    <br><br>
    <a href="${idolo.videoUrl.replace('embed/', 'watch?v=')}" target="_blank" class="btn-ver-yt">
        Ver mejores jugadas en YouTube 📺
    </a>
`;
    modal.style.display = "block";
}

function cerrarModal() {
    document.getElementById('modal-idolo').style.display = "none";
    document.getElementById('video-placeholder').innerHTML = "";
}

// Cerrar si hacen clic fuera de la caja blanca
window.onclick = function(event) {
    const modal = document.getElementById('modal-idolo');
    if (event.target == modal) {
        cerrarModal();
    }
}


function animarContadores() {
    const contadores = document.querySelectorAll('.card h3');
    const velocidad = 200; // Cuanto más alto, más lento

    contadores.forEach(contador => {
        const actualizarContador = () => {
            const valorObjetivo = +contador.innerText;
            const valorActual = 0; // Empezamos desde cero
            
            // Lógica simple para que el número suba (puedes usar una librería como CountUp.js para algo más pro)
            let i = 0;
            let intervalo = setInterval(() => {
                if (i < valorObjetivo) {
                    i++;
                    contador.innerText = i;
                } else {
                    clearInterval(intervalo);
                }
            }, 100);
        };
        
        actualizarContador();
    });
}

const datosTitulos = {
    estrellas: [
        { año: "1977", rival: "Deportivo Cali", forma: "Cuadrangular final", estrellas: "Juan Ramón Verón" },
        { año: "1980", rival: "Deportivo Cali", forma: "Cuadrangular final", estrellas: "Gabriel Berdugo" },
        { año: "1993", rival: "América de Cali", forma: "Gol agónico de Mackenzie", estrellas: "Pibe Valderrama" },
        { año: "1995", rival: "América de Cali", forma: "Gran final", estrellas: "Iván René Valenciano" },
        { año: "2004-II", rival: "Atlético Nacional", forma: "Penales (Inolvidable)", estrellas: "Sebastián Hernández" },
        { año: "2010-I", rival: "La Equidad", forma: "Partido completo (3-1)", estrellas: "Giovanni Hernández" },
        { año: "2011-II", rival: "Once Caldas", forma: "Penales", estrellas: "Carlos Bacca" },
        { año: "2018-II", rival: "Independiente Medellín", forma: "Global 5-4", estrellas: "Teófilo Gutiérrez" },
        { año: "2019-I", rival: "Deportivo Pasto", forma: "Penales", estrellas: "Sebastian Viera" },
        { año: "2023-II", rival: "Independiente Medellín", forma: "Penales (La Décima)", estrellas: "Carlos Bacca y Vladimir Hernández" },
        { año: "2025-II", rival: "Tolima", forma: "Partido completo (La 11)", estrellas: "Jose David Enamorado" } // Ajusta según la historia real
    ],
    copas: [
        { año: "2015", rival: "Santa Fe", forma: "Global 2-1", estrellas: "Vladimir Hernández" },
        { año: "2017", rival: "Independiente Medellín", forma: "Global 3-1", estrellas: "Yony González" }
    ],
    superliga: [
        { año: "2019", rival: "Tolima", forma: "Penales", estrellas: "Luis Díaz" },
        { año: "2020", rival: "América de Cali", forma: "Global 3-2", estrellas: "Miguel Borja" }
    ]
};


function abrirLineaTiempo(tipo) {
    const modal = document.getElementById('modal-titulos');
    const contenedor = document.getElementById('contenedor-linea-tiempo');
    const tituloModal = document.getElementById('titulo-modal-dinamico');
    

    contenedor.innerHTML = "";
    
    tituloModal.innerText = tipo === 'estrellas' ? "Camino a las 11 Estrellas" : 
                        tipo === 'copas' ? "Títulos de Copa Colombia" : "Títulos de Superliga";


    const listaTitulos = datosTitulos[tipo];

    listaTitulos.forEach((t, index) => {
        const item = `
            <div class="timeline-titulo-item" data-aos="fade-up">
                <div class="año-circulo">${t.año}</div>
                <div class="detalle-titulo">
                    <h4>Rival: ${t.rival}</h4>
                    <p><strong>Definición:</strong> ${t.forma}</p>
                    <p><strong>Figura:</strong> ${t.estrellas}</p>
                </div>
            </div>
        `;
        contenedor.innerHTML += item;
    });

    modal.style.display = "block";

    document.querySelector('.modal-content').scrollTop = 0;
}

function cerrarModalTitulos() {
    document.getElementById('modal-titulos').style.display = "none";
}

document.addEventListener('DOMContentLoaded', function() {
    verificarUsuario();
});

function verificarUsuario() {
    const userMenu = document.getElementById('user-menu');
    const datosGuardados = localStorage.getItem('usuarioJunior');

    if (datosGuardados) {
        const data = JSON.parse(datosGuardados);
        
        // Cambiamos el contenido del menú por el nombre del usuario
        userMenu.innerHTML = `
            <div class="user-info">
                <span class="user-name">Hola, ${data.usuario} 🔴⚪</span>
                <button onclick="cerrarSesion()" class="btn-logout">Salir</button>
            </div>
        `;
    }
}

function cerrarSesion() {
    localStorage.removeItem('usuarioJunior'); 
    window.location.reload(); 
}

const btnLogin = document.getElementById('btn-login');

if (btnLogin) { // 
    btnLogin.addEventListener('click', () => {
        console.log("Clic en login");
    });
}

let indiceActual = 0;
const slides = document.querySelectorAll('.slide');

function cambiarSlide() {
    // Quita la clase activa de la imagen actual
    slides[indiceActual].classList.remove('activa');
    
    // Calcula el siguiente índice
    indiceActual = (indiceActual + 1) % slides.length;
    
    // Añade la clase activa a la nueva imagen
    slides[indiceActual].classList.add('activa');
}

// Cambiar automáticamente cada 5000 milisegundos (5 segundos)
setInterval(cambiarSlide, 5000);


function actualizarMenuUsuario() {
    const userMenu = document.getElementById('user-menu');
    const usuarioLogueado = JSON.parse(localStorage.getItem('usuarioJunior'));

    if (usuarioLogueado) {
        // Si hay alguien, mostramos el saludo y el botón de salir
        userMenu.innerHTML = `
            <div class="user-info-container">
                <span class="user-greeting">Hola, ${usuarioLogueado.usuario}</span>
                <button id="btn-salir" class="btn-salir-mini">Salir</button>
            </div>
        `;

        // Programamos el botón de salir
        document.getElementById('btn-salir').addEventListener('click', () => {
            localStorage.removeItem('usuarioJunior'); // Borra la sesión
            window.location.reload(); // Recarga para que vuelva el botón de Iniciar Sesión
        });
    } else {
        // Si no hay nadie, mostramos el botón de Iniciar Sesión original
        userMenu.innerHTML = `<a href="login.html" class="btn-login">Iniciar Sesión</a>`;
    }
}

// Ejecutar la función apenas cargue la página
document.addEventListener('DOMContentLoaded', actualizarMenuUsuario);